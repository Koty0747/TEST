<?php

        if (isset($_POST['valider_donnee'])) 
        {
            extract($_POST);
            if (strlen($telephone) >10) 
            {
                $couleur = "danger";
                $donnee = "Numero de télephone non-valid";
            }
            else
            {
                $req_rech = $db->prepare("SELECT * FROM participant WHERE telephone = ? OR mail = ?");
                $req_rech->execute(array($telephone,$mail));
                $resultat = $req_rech->rowCount();
                if($resultat >= 1)
                {
                    $couleur = "danger";
                    $donnee = "Télephone ou Mail existe deja";
                }
                else {
                    
                    $req_insert_participant = $db->prepare("INSERT INTO participant(ref_participant,nom,prenoms,telephone,mail)VALUES (:ref_participant,:nom,:prenoms,:telephone,:mail)");
                    $req_insert_participant->execute(array(
                      'ref_participant' =>"PART-".substr($nom,0,1).substr($prenoms,0,1)."001" ,
                      'nom' => $nom ,
                      'prenoms' => $prenoms ,
                      'telephone' => $telephone ,
                      'mail' => $mail
                                     )
                          );
                    $couleur = "success";
                    $donnee ="Participant inserer avec succes";
                    }
            }
            
       } 
?>