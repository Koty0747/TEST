<?php

$req_liste = $db->prepare("SELECT * FROM participant");
$req_liste->execute();
                
?>